package com.personalai.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class Message(val text: String, val user: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PersonalAI() }
    }
}

@Composable
fun PersonalAI() {
    var tab by remember { mutableStateOf("Chat") }
    var input by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf(
        Message("Hello! I'm your Personal AI Assistant. V1 mobile workspace is ready.", false)
    )}

    MaterialTheme(colorScheme = darkColorScheme(
        background = Color(0xFF080B12),
        surface = Color(0xFF111724),
        primary = Color(0xFF8B7CFF)
    )) {
        Column(Modifier.fillMaxSize().background(Color(0xFF080B12))) {
            Row(
                Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("✦ Personal AI", fontSize = 21.sp, fontWeight = FontWeight.Bold)
                    Text("Advanced personal assistant", color = Color.Gray, fontSize = 12.sp)
                }
                AssistChip(onClick = {}, label = { Text("ONLINE") })
            }

            ScrollableTabRow(selectedTabIndex = listOf(
                "Chat","Voice","Memory","Agents","Automation","Files","Browser","PC"
            ).indexOf(tab).coerceAtLeast(0)) {
                listOf("Chat","Voice","Memory","Agents","Automation","Files","Browser","PC")
                    .forEach { t ->
                        Tab(selected = tab == t, onClick = { tab = t }, text = { Text(t) })
                    }
            }

            if (tab == "Chat") {
                LazyColumn(
                    Modifier.weight(1f).fillMaxWidth().padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(messages) { m ->
                        Surface(
                            color = if (m.user) Color(0xFF1D2636) else Color(0xFF111724),
                            shape = MaterialTheme.shapes.large,
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(m.text, Modifier.padding(15.dp), fontSize = 14.sp) }
                    }
                }
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = input, onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Ask your assistant...") },
                        singleLine = true
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        if (input.isNotBlank()) {
                            val command = input.trim()
                            messages.add(Message(command, true))
                            messages.add(Message(localResponse(command), false))
                            input = ""
                        }
                    }) { Text("➤") }
                }
            } else {
                FeatureScreen(tab)
            }
        }
    }
}

fun localResponse(command: String): String {
    val c = command.lowercase()
    return when {
        c.contains("remember") -> "Memory command detected. Persistent memory connector is ready for the next integration."
        c.contains("open") -> "PC/browser action detected. Connect the Windows companion to execute this action."
        c.contains("system") -> "System command detected. Windows companion can return CPU, RAM, disk and process data."
        else -> "Command received. The mobile assistant is ready to route this task to the AI/Windows agent."
    }
}

@Composable
fun FeatureScreen(name: String) {
    val descriptions = mapOf(
        "Voice" to "Voice assistant • speech input • spoken responses • wake-word integration",
        "Memory" to "Long-term memory • preferences • conversation history • editable memories",
        "Agents" to "Researcher • Coder • Browser • File • PC Control • custom agents",
        "Automation" to "Workflows • schedules • triggers • conditions • task queue",
        "Files" to "File search • document analysis • PDF/Office workflows • organization",
        "Browser" to "Web research • page navigation • extraction • browser automation",
        "PC" to "Windows companion • mouse/keyboard • apps • screen understanding • system control"
    )
    Column(Modifier.fillMaxSize().padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(name, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(descriptions[name] ?: "Personal AI workspace", color = Color.LightGray)
        FeatureCard("Ready", "This module is included in the project architecture. Advanced execution connects through the AI backend and Windows companion.")
        FeatureCard("Security", "Sensitive actions should require explicit confirmation. API keys and private data should be stored securely.")
        FeatureCard("Next", "Connect this Android client to the AI backend and Windows companion for real actions.")
    }
}

@Composable
fun FeatureCard(title: String, body: String) {
    Surface(color = Color(0xFF111724), shape = MaterialTheme.shapes.large) {
        Column(Modifier.padding(18.dp)) {
            Text(title, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            Text(body, color = Color.Gray, fontSize = 13.sp)
        }
    }
}
