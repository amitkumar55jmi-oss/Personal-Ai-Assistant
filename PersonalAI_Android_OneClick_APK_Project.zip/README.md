# Personal AI Android

Android Studio project for the Personal AI Assistant.

## Build APK
1. Install Android Studio.
2. Open this folder.
3. Let Gradle sync.
4. Connect an Android phone with USB debugging enabled or use an emulator.
5. Run the app.
6. For APK: Build > Generate App Bundles or APKs > Generate APKs.

## Architecture
The mobile client contains the complete feature navigation for Chat, Voice, Memory, Agents, Automation, Files, Browser and PC Control.

Important: Android cannot directly perform unrestricted Windows desktop automation. Those features require the Windows companion/agent and a secure connection.

This project is a foundation; production AI, persistent cloud/local sync, browser automation and Windows control require their respective backend/companion integrations.
