# PersonalAI — One-Click APK Build

This project includes a GitHub Actions workflow that builds the Android APK for you.

## Easiest method (recommended)

1. Create a new GitHub repository.
2. Upload all files/folders from this project to the repository.
3. Open the repository's **Actions** tab.
4. Select **Build PersonalAI APK**.
5. Click **Run workflow**.
6. Wait for the build to finish.
7. Open the completed workflow run.
8. Under **Artifacts**, download **PersonalAI-debug-APK**.
9. Extract the downloaded artifact and install `app-debug.apk` on Android.

The workflow uses:
- Ubuntu GitHub runner
- JDK 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3

## Local build

If Gradle 8.9 is installed and available as `gradle` in PATH, run:

    build-apk.bat

The APK will be generated at:

    app/build/outputs/apk/debug/app-debug.apk

## Important

This is a debug APK for testing. It is not Play Store signed.

Also, the current Android app is the PersonalAI UI/foundation. The advanced
Stonic-like capabilities (real AI provider, unrestricted PC control,
phone-to-PC pairing, autonomous browser/file agents, etc.) still need their
backend/Windows companion implementations and permissions.
