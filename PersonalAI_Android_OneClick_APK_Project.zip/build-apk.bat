\
    @echo off
    setlocal
    echo ==========================================
    echo       PersonalAI - APK Builder
    echo ==========================================
    echo.
    where gradle >nul 2>nul
    if errorlevel 1 (
      echo Gradle was not found.
      echo For the easiest build, upload this project to GitHub
      echo and use Actions ^> Build PersonalAI APK ^> Run workflow.
      echo.
      pause
      exit /b 1
    )
    gradle --no-daemon :app:assembleDebug
    if errorlevel 1 (
      echo.
      echo APK build failed.
      pause
      exit /b 1
    )
    echo.
    echo APK created at:
    echo app\build\outputs\apk\debug\app-debug.apk
    pause
